from django.shortcuts import render, HttpResponseRedirect
from .forms import CategorieForm
from . import models

def ajoutcategorie(request):
    if request.method == "POST":
        form = CategorieForm(request)
        return render(request, "categorie/ajout.html",{"form": form})
    else :
        form = CategorieForm()
        return render(request, "categorie/ajout.html", {"form": form})

def traitementcategorie(request):
    lform = CategorieForm(request.POST)
    if lform.is_valid():
        categorie = lform.save()
        return HttpResponseRedirect("/concession/")
    else :
        return render(request, "categorie/ajout.html", {"form": lform})

def indexcategorie(request):
    liste = list(models.Categorie.objects.all())
    return render(request, "categorie/index.html",{"liste": liste})

def affichecategorie(request, id):
    categorie = models.Categorie.objects.get(pk=id)
    liste = models.Moto.objects.filter(categorie_id = id)
    return render(request, "categorie/affiche.html", {"categorie": categorie, "liste": liste})

def updatecategorie(request, id):
    categorie = models.Categorie.objects.get(pk=id)
    form = CategorieForm(categorie.dico())
    return render(request,"categorie/update.html",{"form": form, "id": id})

def traitementupdatecategorie(request, id):
    lform = CategorieForm(request.POST)
    if lform.is_valid():
        categorie = lform.save(commit=False)
        categorie.id = id
        categorie.save()
        return HttpResponseRedirect("/concession/")
    else:
        return render(request, "categorie/update.html", {"form": lform, "id": id})

def deletecategorie(request, id):
    categorie = models.Categorie.objects.get(pk=id)
    categorie.delete()
    return HttpResponseRedirect("/concession/")