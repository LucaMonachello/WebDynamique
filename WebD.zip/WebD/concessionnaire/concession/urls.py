from django.urls import path
from . import views, categorie_views

urlpatterns = [
    path("ajout/<int:id>/", views.ajout),
    path("traitement/<int:id>/", views.traitement),
    path("indexmoto/", views.indexmoto),
    path("affiche/<int:id>/", views.affiche),
    path("update/<int:id>/", views.update),
    path("traitementupdate/<int:id>/", views.traitementupdate),
    path("delete/<int:id>/", views.delete),
    #PATH pour catégorie
    path("ajoutcategorie/", categorie_views.ajoutcategorie),
    path("traitementcategorie/", categorie_views.traitementcategorie),
    path("", categorie_views.indexcategorie),
    path("affichecategorie/<int:id>/", categorie_views.affichecategorie),
    path("updatecategorie/<int:id>/", categorie_views.updatecategorie),
    path("traitementupdatecategorie/<int:id>/", categorie_views.traitementupdatecategorie),
    path("deletecategorie/<int:id>/", categorie_views.deletecategorie),

    ]
