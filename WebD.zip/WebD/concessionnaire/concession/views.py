from django.shortcuts import render
from django.http import HttpResponseRedirect
from .forms import MotoForm
from . import models

def ajout(request, id):
        form = MotoForm()
        return render(request, "moto/ajout.html", {"form": form, "id": id})

def traitement(request, id):
    categorie = models.Categorie.objects.get(pk=id)
    lform = MotoForm(request.POST)
    if lform.is_valid():
        moto = lform.save(commit=False)
        moto.categorie = categorie
        moto.categorie_id = id
        moto.save()
        return HttpResponseRedirect("/concession/")
    else :
        return render(request, "concession/moto/ajout.html", {"form": lform})

def indexmoto(request):
    liste = list(models.Moto.objects.all())
    return render(request, "moto/index.html",{"liste": liste})

def affiche(request, id):
    moto = models.Moto.objects.get(pk=id)
    return render(request, "moto/affiche.html", {"moto": moto})

def update(request, id):
    moto = models.Moto.objects.get(pk=id)
    form = MotoForm(moto.dico())
    return render(request,"moto/update.html",{"form": form, "id": id})

def traitementupdate(request, id):
    lform = MotoForm(request.POST)
    if lform.is_valid():
        Moto = lform.save(commit=False)
        Moto.id = id
        Moto.save()
        return HttpResponseRedirect("/concession/")
    else:
        return render(request, "moto/update.html", {"form": lform, "id": id})

def delete(request, id):
    moto = models.Moto.objects.get(pk=id)
    moto.delete()
    return HttpResponseRedirect("/concession/")
