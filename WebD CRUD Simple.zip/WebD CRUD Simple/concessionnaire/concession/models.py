from django.db import models


class Moto(models.Model):
    modele = models.CharField(max_length=100)
    marque = models.CharField(max_length=100)
    date_sortie = models.IntegerField(blank=True, null=True)
    puissance = models.IntegerField(blank=True, null=True)


    def __str__(self):
        chaine = f"{self.modele} crée par {self.marque} sortie en {self.date_sortie} développant {self.puissance} chevaux."
        return chaine

    def dico(self):
        return {"modele": self.modele, "marque": self.marque, "date_sortie": self.date_sortie, "puissance": self.puissance}


