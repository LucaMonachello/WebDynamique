from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from . import models

class MotoForm(ModelForm):
    class Meta:
        model = models.Moto
        fields = ('modele', 'marque', 'date_sortie', 'puissance')
        labels = {
            'modele' : _('Modèle'),
            'marque' : _('Marque') ,
            'date_sortie' : _('Date de sortie'),
            'puissance' : _('Chevaux'),

        }

